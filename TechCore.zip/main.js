
const products = [
  {id:"1",name:"Intel Core i9-14900K",category:"procesoare",brand:"Intel",price:12499,image:"https://neocomputer.md/image/cache/catalog/products/ai-products/93241/img93241_1-800x800.jpg",description:"Procesor de ultimă generație pentru gaming și aplicații profesionale",specs:{Socket:"LGA1700",Nuclee:"24 (8P+16E)",Frecvență:"3.0 GHz - 6.0 GHz",Cache:"36MB L3",TDP:"125W"},inStock:true},
  {id:"2",name:"AMD Ryzen 9 7950X",category:"procesoare",brand:"AMD",price:11999,image:"https://xstore.md/images/product/2023/05/xstore.md-Procesor-AMD-Ryzen-9-7950X-Tray-(1).jpg",description:"Performanță supremă pentru workstation și gaming",specs:{Socket:"AM5",Nuclee:"16",Frecvență:"4.5 GHz - 5.7 GHz",Cache:"64MB L3",TDP:"170W"},inStock:true},
  {id:"3",name:"NVIDIA RTX 4090",category:"placi-video",brand:"NVIDIA",price:38999,image:"https://cdn-ultra.esempla.com/storage/webp/ebc7fcf2-df28-442f-ac61-48d5a2e53232.webp",description:"Cea mai puternică placă video pentru gaming și creație",specs:{Memorie:"24GB GDDR6X","CUDA Cores":"16384",Frecvență:"2.52 GHz",TDP:"450W",Conectori:"DisplayPort 1.4a, HDMI 2.1"},inStock:true},
  {id:"4",name:"AMD Radeon RX 7900 XTX",category:"placi-video",brand:"AMD",price:24999,image:"https://xstore.md/images/product/2024/02/GIGABYTE-Radeon-RX-7900-XTX-GAMING-OC-24G--1-.png",description:"Performanță excepțională la un preț competitiv",specs:{Memorie:"24GB GDDR6","Stream Processors":"6144",Frecvență:"2.5 GHz",TDP:"355W",Conectori:"DisplayPort 2.1, HDMI 2.1"},inStock:true},
  {id:"5",name:"ASUS ROG STRIX Z790-E",category:"placi-baza",brand:"ASUS",price:8999,image:"https://xstore.md/images/product/2023/12/Asus-ROG-STRIX-Z790-F-GAMING-WIFI-II--1-.png",description:"Placă de bază premium pentru Intel Gen 14",specs:{Socket:"LGA1700",Chipset:"Intel Z790",RAM:"DDR5 7800MHz (OC)",Sloturi:"4x DIMM, Max 128GB",M2:"5x slots PCIe 5.0/4.0"},inStock:true},
  {id:"6",name:"MSI MAG X670E TOMAHAWK",category:"placi-baza",brand:"MSI",price:7499,image:"https://storage-asset.msi.com/global/picture/image/feature/mb/X670E/mag-x670e-tomahawk-wifi/mag-x670e-tomahawk-wifi.png",description:"Placă de bază robustă pentru AMD Ryzen 7000",specs:{Socket:"AM5",Chipset:"AMD X670E",RAM:"DDR5 6400MHz (OC)",Sloturi:"4x DIMM, Max 128GB",M2:"4x slots PCIe 5.0/4.0"},inStock:true},
  {id:"7",name:"Dell XPS 15 9530",category:"laptopuri",brand:"Dell",price:22999,image:"https://neocomputer.md/image/cache/catalog/category%20image/Dell%20XPS%2015%209530,%20Platinum%20Silver-800x800.jpg",description:"Laptop premium pentru profesioniști",specs:{Procesor:"Intel Core i7-13700H",RAM:"32GB DDR5",Stocare:"1TB NVMe SSD",Display:'15.6" 3.5K OLED Touch',GPU:"NVIDIA RTX 4060 8GB"},inStock:true},
  {id:"8",name:"ASUS ROG Zephyrus G16",category:"laptopuri",brand:"ASUS",price:28999,image:"https://cdn-ultra.esempla.com/storage/webp/c27b405a-1d6e-4c97-8e66-75c491f81c43.webp",description:"Gaming laptop ultraportabil",specs:{Procesor:"Intel Core i9-14900HS",RAM:"32GB DDR5",Stocare:"2TB NVMe SSD",Display:'16" 2.5K 240Hz',GPU:"NVIDIA RTX 4080 12GB"},inStock:true},
  {id:"9",name:"Logitech G Pro X Superlight",category:"periferice",brand:"Logitech",price:1499,image:"https://xstore.md/images/product/2024/02/Logitech-PRO-X-Superlight-2-white--1-.png",description:"Mouse wireless ultra-ușor pentru gaming profesional",specs:{Senzor:"HERO 25K",DPI:"100-25,600",Greutate:"63g",Baterie:"70 ore",Conexiune:"LIGHTSPEED Wireless"},inStock:true},
  {id:"10",name:"Corsair K70 RGB Pro",category:"periferice",brand:"Corsair",price:1899,image:"https://assets.corsair.com/image/upload/c_pad,q_auto,h_1024,w_1024,f_auto/products/Gaming-Keyboards/CH-9109410-NA/Gallery/K70_RGB_PRO_PBT_01.webp",description:"Tastatură mecanică premium cu iluminare RGB",specs:{Switch:"Cherry MX Red",Iluminare:"Per-Key RGB",Conexiune:"USB Type-C","Polling Rate":"1000Hz","N-Key Rollover":"Da"},inStock:true},
  {id:"11",name:"Samsung 980 PRO 2TB",category:"stocare",brand:"Samsung",price:2499,image:"https://neocomputer.md/image/cache/data/Componente%20PC/HDD/SSD%20Drives/M.2%20NVMe%20SSD/2.0Tb%20Samsung%20980%20PRO_1-800x800.jpg",description:"SSD NVMe ultra-rapid pentru sistem și jocuri",specs:{Capacitate:"2TB",Interfață:"PCIe 4.0 x4 NVMe",Citire:"7,000 MB/s",Scriere:"5,100 MB/s",MTBF:"1.5M ore"},inStock:true},
  {id:"12",name:"Corsair Vengeance DDR5 32GB",category:"memorie",brand:"Corsair",price:1999,image:"https://assets.corsair.com/image/upload/c_pad,q_85,h_1100,w_1100,f_auto/products/Memory/vengeance-rgb-ddr5-blk-config/Gallery/Vengeance-RGB-DDR5-2UP-BLACK_01.webp",description:"Kit memorie DDR5 de înaltă performanță",specs:{Capacitate:"32GB (2x16GB)",Tip:"DDR5",Frecvență:"6000MHz",Latență:"CL36",Voltaj:"1.35V"},inStock:true}
];

const categories = [
  {id:"procesoare",name:"Procesoare"},
  {id:"placi-video",name:"Plăci Video"},
  {id:"placi-baza",name:"Plăci de Bază"},
  {id:"laptopuri",name:"Laptopuri"},
  {id:"periferice",name:"Periferice"},
  {id:"stocare",name:"Stocare"},
  {id:"memorie",name:"Memorie RAM"}
];

let currentCategory = "toate";
let selectedBrands = [];
let currentQty = 1;

function showPage(page) {
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.getElementById('page-' + page).classList.add('active');
  document.querySelectorAll('.nav-links a').forEach(a => a.classList.remove('active'));
  const navEl = document.getElementById('nav-' + page);
  if (navEl) navEl.classList.add('active');
  window.scrollTo(0, 0);
}

function productCard(p, showAdd) {
  return `<div class="product-card" onclick="showDetail('${p.id}')">
    <div class="product-img">
      <img src="${p.image}" alt="${p.name}" loading="lazy" />
      ${!p.inStock ? '<div style="position:absolute;inset:0;background:rgba(0,0,0,0.6);display:flex;align-items:center;justify-content:center"><span style="padding:8px 18px;background:#ef4444;border-radius:8px;font-size:14px;font-weight:600">Stoc Epuizat</span></div>' : ''}
    </div>
    <div class="product-info">
      <div class="product-brand">${p.brand}</div>
      <div class="product-name">${p.name}</div>
      <div class="product-price">${p.price.toLocaleString()} MDL</div>
      <div class="product-actions">
        <a class="btn-detail" href="#" onclick="event.stopPropagation();showDetail('${p.id}')">Vezi Detalii</a>
        ${p.inStock && showAdd ? `<button class="btn-add" onclick="event.stopPropagation();addToCart('${p.id}',1)">Adaugă</button>` : ''}
      </div>
    </div>
  </div>`;
}

function renderHome() {
  document.getElementById('home-products').innerHTML = products.slice(0,6).map(p => productCard(p, false)).join('');
}

function filterByCategory(cat) {
  currentCategory = cat;
  document.querySelectorAll('#category-filters .filter-btn').forEach(b => {
    b.classList.toggle('active', b.dataset.cat === cat);
  });
  const resetBtn = document.getElementById('reset-cat');
  if (resetBtn) resetBtn.style.display = cat !== 'toate' ? 'inline' : 'none';
  applyFilters();
}

function resetBrands() {
  selectedBrands = [];
  document.querySelectorAll('#brand-filters input').forEach(i => i.checked = false);
  document.getElementById('reset-brands').style.display = 'none';
  applyFilters();
}

function applyFilters() {
  const minP = parseInt(document.getElementById('price-min').value) || 0;
  const maxP = parseInt(document.getElementById('price-max').value) || 50000;
  const inStockOnly = document.getElementById('in-stock-filter').checked;
  const searchQ = document.getElementById('search-input').value.toLowerCase();

  const filtered = products.filter(p => {
    if (currentCategory !== 'toate' && p.category !== currentCategory) return false;
    if (selectedBrands.length > 0 && !selectedBrands.includes(p.brand)) return false;
    if (p.price < minP || p.price > maxP) return false;
    if (inStockOnly && !p.inStock) return false;
    if (searchQ && !p.name.toLowerCase().includes(searchQ) && !p.brand.toLowerCase().includes(searchQ)) return false;
    return true;
  });

  const grid = document.getElementById('filtered-products');
  const noProd = document.getElementById('no-products');
  document.getElementById('products-count').textContent = filtered.length + ' produse găsite';

  if (filtered.length === 0) {
    grid.innerHTML = '';
    noProd.style.display = 'block';
  } else {
    noProd.style.display = 'none';
    grid.innerHTML = filtered.map(p => productCard(p, true)).join('');
  }
}

function handleSearch() {
  if (document.getElementById('page-products').classList.contains('active')) {
    applyFilters();
  }
}

function renderProductFilters() {
  const catEl = document.getElementById('category-filters');
  catEl.innerHTML = `<button class="filter-btn active" data-cat="toate" onclick="filterByCategory('toate')">Toate categoriile</button>` +
    categories.map(c => `<button class="filter-btn" data-cat="${c.id}" onclick="filterByCategory('${c.id}')">${c.name}</button>`).join('');

  const brands = [...new Set(products.map(p => p.brand))];
  document.getElementById('brand-filters').innerHTML = brands.map(b =>
    `<label class="filter-check"><input type="checkbox" value="${b}" onchange="toggleBrand('${b}')" /><span>${b}</span></label>`
  ).join('');
}

function toggleBrand(brand) {
  if (selectedBrands.includes(brand)) {
    selectedBrands = selectedBrands.filter(b => b !== brand);
  } else {
    selectedBrands.push(brand);
  }
  document.getElementById('reset-brands').style.display = selectedBrands.length > 0 ? 'inline' : 'none';
  applyFilters();
}

function showDetail(id) {
  const p = products.find(x => x.id === id);
  if (!p) return;
  currentQty = 1;
  const images = [p.image, p.image, p.image, p.image];

  document.getElementById('detail-content').innerHTML = `
    <div>
      <div class="detail-img-main"><img id="main-img" src="${p.image}" alt="${p.name}" /></div>
      <div class="detail-thumbs">
        ${images.map((img,i) => `<div class="thumb ${i===0?'active':''}" onclick="selectThumb(this,'${img}')"><img src="${img}" alt="" /></div>`).join('')}
      </div>
    </div>
    <div>
      <div class="detail-brand">${p.brand}</div>
      <h1 class="detail-title">${p.name}</h1>
      <p class="detail-desc">${p.description}</p>
      <div class="detail-price-row">
        <span class="detail-price">${p.price.toLocaleString()} MDL</span>
        ${p.inStock ? '<span class="in-stock"><svg viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg>În stoc</span>' : '<span style="color:#ef4444;font-size:15px;font-weight:500">Stoc epuizat</span>'}
      </div>
      <div class="qty-row">
        <label>Cantitate:</label>
        <div class="qty-ctrl">
          <button onclick="changeQty(-1)">−</button>
          <span id="qty-val">1</span>
          <button onclick="changeQty(1)">+</button>
        </div>
      </div>
      <div class="detail-btns">
        <button class="btn-cart" onclick="addToCart('${p.id}', currentQty)">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="9" cy="21" r="1"></circle><circle cx="20" cy="21" r="1"></circle><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"></path></svg>
          Adaugă în Coș
        </button>
        <button class="btn-wish"><svg viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"></path></svg></button>
        <button class="btn-share"><svg viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="18" cy="5" r="3"></circle><circle cx="6" cy="12" r="3"></circle><circle cx="18" cy="19" r="3"></circle><line x1="8.59" y1="13.51" x2="15.42" y2="17.49"></line><line x1="15.41" y1="6.51" x2="8.59" y2="10.49"></line></svg></button>
      </div>
      <div class="specs-box">
        <h3>Specificații Tehnice</h3>
        ${Object.entries(p.specs).map(([k,v]) => `<div class="spec-row"><span>${k}</span><span>${v}</span></div>`).join('')}
      </div>
    </div>`;

  const related = products.filter(x => x.category === p.category && x.id !== p.id).slice(0,4);
  document.getElementById('related-section').innerHTML = related.length > 0 ? `
    <h2 style="font-size:32px;font-weight:700;margin-bottom:32px">Produse Similare</h2>
    <div class="related-grid">${related.map(r => productCard(r, false)).join('')}</div>` : '';

  showPage('detail');
}

function selectThumb(el, src) {
  document.querySelectorAll('.thumb').forEach(t => t.classList.remove('active'));
  el.classList.add('active');
  document.getElementById('main-img').src = src;
}

function changeQty(delta) {
  currentQty = Math.max(1, currentQty + delta);
  document.getElementById('qty-val').textContent = currentQty;
}

const configComponents = [
  {key:"processor",title:"Procesor",description:"Creierul sistemului tău",options:products.filter(p=>p.category==="procesoare")},
  {key:"motherboard",title:"Placă de Bază",description:"Conectează toate componentele",options:products.filter(p=>p.category==="placi-baza")},
  {key:"gpu",title:"Placă Video",description:"Pentru gaming și grafică",options:products.filter(p=>p.category==="placi-video")},
  {key:"ram",title:"Memorie RAM",description:"Pentru multitasking rapid",options:products.filter(p=>p.category==="memorie")},
  {key:"storage",title:"Stocare SSD",description:"Pentru sistem și aplicații",options:products.filter(p=>p.category==="stocare")},
  {key:"psu",title:"Sursă Alimentare",description:"Putere stabilă pentru sistem",options:[
    {id:"psu1",name:"Corsair RM850x 850W 80+ Gold",price:1499,image:"https://assets.corsair.com/image/upload/akamai/pdp/rmx2021/images/rm850x_hero.png"},
    {id:"psu2",name:"EVGA SuperNOVA 1000W 80+ Platinum",price:1999,image:"https://www.scan.co.uk/images/products/xlarge/3588591-xl-a.jpg"}
  ]}
];

let buildConfig = {processor:null,motherboard:null,gpu:null,ram:null,storage:null,psu:null};
let expandedKeys = {processor:true,motherboard:false,gpu:false,ram:false,storage:false,psu:false};

function renderConfigurator() {
  const el = document.getElementById('config-components');
  el.innerHTML = configComponents.map(comp => {
    const sel = buildConfig[comp.key] ? [...products,{id:"psu1",name:"Corsair RM850x 850W 80+ Gold",price:1499,image:"https://assets.corsair.com/image/upload/akamai/pdp/rmx2021/images/rm850x_hero.png"},{id:"psu2",name:"EVGA SuperNOVA 1000W 80+ Platinum",price:1999,image:"https://www.scan.co.uk/images/products/xlarge/3588591-xl-a.jpg"}].find(p=>p.id===buildConfig[comp.key]) : null;
    const expanded = expandedKeys[comp.key] || !sel;
    return `<div class="config-component">
      <div class="config-component-header">
        <div>
          <h3>${comp.title}<span class="required-star">*</span></h3>
          <p>${comp.description}</p>
        </div>
        ${sel ? '<div class="check-done"><svg viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg></div>' : ''}
      </div>
      <div class="config-component-body">
        ${sel ? `<div class="selected-item">
          <div class="selected-img"><img src="${sel.image}" alt="${sel.name}" /></div>
          <div class="selected-info"><span>${sel.brand||'PSU'}</span><p>${sel.name}</p></div>
          <span class="selected-price">${sel.price.toLocaleString()} MDL</span>
          <button class="change-btn" onclick="toggleExpand('${comp.key}')">Schimbă</button>
        </div>` : ''}
        ${!sel || expanded ? `<div class="options-list">
          ${comp.options.map(opt => `<div class="option-item ${buildConfig[comp.key]===opt.id?'selected':''}" onclick="selectComponent('${comp.key}','${opt.id}')">
            <div class="option-img"><img src="${opt.image}" alt="${opt.name}" loading="lazy" /></div>
            <div class="option-info"><p>${opt.brand||''}</p><span>${opt.name}</span></div>
            <span class="option-price">${opt.price.toLocaleString()} MDL</span>
          </div>`).join('')}
        </div>` : ''}
      </div>
    </div>`;
  }).join('');
  updateConfigSummary();
}

function toggleExpand(key) {
  expandedKeys[key] = !expandedKeys[key];
  renderConfigurator();
}

function selectComponent(key, id) {
  buildConfig[key] = id;
  expandedKeys[key] = false;
  renderConfigurator();
}

function updateConfigSummary() {
  const allProds = [...products,
    {id:"psu1",name:"Corsair RM850x 850W 80+ Gold",price:1499},
    {id:"psu2",name:"EVGA SuperNOVA 1000W 80+ Platinum",price:1999}
  ];
  const labels = {processor:"Procesor",motherboard:"Placă de Bază",gpu:"Placă Video",ram:"Memorie RAM",storage:"Stocare",psu:"Sursă Alimentare"};
  let total = 0;
  let html = '';
  let allSet = true;
  Object.entries(buildConfig).forEach(([key, id]) => {
    const p = id ? allProds.find(x=>x.id===id) : null;
    if (p) {
      total += p.price;
      html += `<div class="summary-item"><span>${labels[key]}</span><span>${p.price.toLocaleString()} MDL</span></div>`;
    } else {
      allSet = false;
      html += `<div class="summary-item"><span>${labels[key]}</span><span style="color:var(--muted2)">—</span></div>`;
    }
  });
  document.getElementById('config-summary-items').innerHTML = html;
  document.getElementById('config-total').textContent = total.toLocaleString() + ' MDL';
  const warn = document.getElementById('config-warning');
  const btn = document.getElementById('order-btn');
  warn.style.display = allSet ? 'none' : 'flex';
  btn.disabled = !allSet;
  btn.style.opacity = allSet ? '1' : '0.5';
  btn.style.cursor = allSet ? 'pointer' : 'not-allowed';
}

function submitContact() {
  const name = document.getElementById('contact-name').value.trim();
  const email = document.getElementById('contact-email').value.trim();
  const msg = document.getElementById('contact-msg').value.trim();
  if (!name || !email || !msg) { alert('Te rugăm completează toate câmpurile.'); return; }
  document.getElementById('contact-form-wrap').style.display = 'none';
  document.getElementById('contact-success').style.display = 'block';
  setTimeout(() => {
    document.getElementById('contact-form-wrap').style.display = 'block';
    document.getElementById('contact-success').style.display = 'none';
    document.getElementById('contact-name').value = '';
    document.getElementById('contact-email').value = '';
    document.getElementById('contact-msg').value = '';
  }, 3000);
}

function validateEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}
function validatePhone(phone) {
  return /^\d{7,15}$/.test(phone.replace(/\s/g,''));
}
function showField(id, show) {
  const el = document.getElementById(id);
  if (el) el.classList.toggle('show', show);
}
function markInput(id, err) {
  const el = document.getElementById(id);
  if (el) el.classList.toggle('error', err);
}
function showAlert(id, msg, type) {
  const el = document.getElementById(id);
  if (!el) return;
  el.textContent = msg;
  el.className = 'auth-alert ' + type + ' show';
}
function hideAlert(id) {
  const el = document.getElementById(id);
  if (el) el.className = 'auth-alert';
}

function registerUser() {
  hideAlert('reg-alert');
  const last  = document.getElementById('reg-last').value.trim();
  const first = document.getElementById('reg-first').value.trim();
  const email = document.getElementById('reg-email').value.trim();
  const phone = document.getElementById('reg-phone').value.trim();
  const pass  = document.getElementById('reg-pass').value;
  const pass2 = document.getElementById('reg-pass2').value;

  let valid = true;
  const checks = [
    ['reg-last',  'err-last',  !last,                       'Câmpul este obligatoriu'],
    ['reg-first', 'err-first', !first,                      'Câmpul este obligatoriu'],
    ['reg-email', 'err-email', !validateEmail(email),        'Email invalid (ex: user@domain.com)'],
    ['reg-phone', 'err-phone', !validatePhone(phone),        'Telefonul trebuie să conțină doar cifre'],
    ['reg-pass',  'err-pass',  pass.length < 8,              'Parola trebuie să aibă cel puțin 8 caractere'],
    ['reg-pass2', 'err-pass2', pass !== pass2,               'Parolele nu coincid'],
  ];
  checks.forEach(([inp, err, cond, msg]) => {
    document.getElementById(err).textContent = msg;
    showField(err, cond);
    markInput(inp, cond);
    if (cond) valid = false;
  });
  if (!valid) return;

  const users = JSON.parse(localStorage.getItem('tc_users') || '[]');
  if (users.find(u => u.email === email)) {
    showAlert('reg-alert', '⚠️ Există deja un cont cu acest email.', 'error-msg');
    return;
  }
  users.push({ last, first, email, phone, pass });
  localStorage.setItem('tc_users', JSON.stringify(users));
  showAlert('reg-alert', '✅ Cont creat cu succes! Te redirecționăm...', 'success');
  setTimeout(() => { showPage('login'); hideAlert('reg-alert'); }, 1800);
}

function loginUser() {
  hideAlert('login-alert');
  const email = document.getElementById('login-email').value.trim();
  const pass  = document.getElementById('login-pass').value;

  let valid = true;
  [['login-email','err-login-email',!validateEmail(email),'Email invalid'],
   ['login-pass','err-login-pass',!pass,'Câmpul este obligatoriu']
  ].forEach(([inp,err,cond,msg]) => {
    document.getElementById(err).textContent = msg;
    showField(err, cond); markInput(inp, cond);
    if (cond) valid = false;
  });
  if (!valid) return;

  const users = JSON.parse(localStorage.getItem('tc_users') || '[]');
  const user  = users.find(u => u.email === email && u.pass === pass);
  if (!user) {
    showAlert('login-alert', '❌ Email sau parolă incorectă.', 'error-msg');
    return;
  }
  localStorage.setItem('tc_current_user', JSON.stringify(user));
  updateNavAuth(user);
  showAlert('login-alert', `✅ Bun venit, ${user.first}! Te redirecționăm...`, 'success');
  setTimeout(() => { showPage('home'); hideAlert('login-alert'); }, 1500);
}

function logoutUser() {
  localStorage.removeItem('tc_current_user');
  updateNavAuth(null);
  showPage('home');
}

function updateNavAuth(user) {
  const authArea = document.getElementById('nav-auth-area');
  const userArea = document.getElementById('nav-user-area');
  const nameEl   = document.getElementById('nav-username');
  if (user) {
    authArea.style.display = 'none';
    userArea.style.display = 'flex';
    nameEl.textContent = `👋 ${user.first} ${user.last}`;
  } else {
    authArea.style.display = 'flex';
    userArea.style.display = 'none';
  }
}

const dealsData = [
  {id:"d1", name:"Intel Core i9-14900K", category:"procesoare", brand:"Intel",
   image:"https://neocomputer.md/image/cache/catalog/products/ai-products/93241/img93241_1-800x800.jpg",
   priceNew:10999, priceOld:12499, discount:12, stock:"În stoc"},
  {id:"d2", name:"NVIDIA RTX 4090 Founders Edition", category:"placi-video", brand:"NVIDIA",
   image:"https://cdn-ultra.esempla.com/storage/webp/ebc7fcf2-df28-442f-ac61-48d5a2e53232.webp",
   priceNew:34999, priceOld:38999, discount:10, stock:"Ultimele 3 bucăți"},
  {id:"d3", name:"AMD Ryzen 9 7950X", category:"procesoare", brand:"AMD",
   image:"https://xstore.md/images/product/2023/05/xstore.md-Procesor-AMD-Ryzen-9-7950X-Tray-(1).jpg",
   priceNew:9499, priceOld:11999, discount:21, stock:"În stoc"},
  {id:"d4", name:"ASUS ROG Zephyrus G16", category:"laptopuri", brand:"ASUS",
   image:"https://cdn-ultra.esempla.com/storage/webp/c27b405a-1d6e-4c97-8e66-75c491f81c43.webp",
   priceNew:24999, priceOld:28999, discount:14, stock:"Ultimele 2 bucăți"},
  {id:"d5", name:"Logitech G Pro X Superlight 2", category:"periferice", brand:"Logitech",
   image:"https://xstore.md/images/product/2024/02/Logitech-PRO-X-Superlight-2-white--1-.png",
   priceNew:1199, priceOld:1499, discount:20, stock:"În stoc"},
  {id:"d6", name:"Samsung 980 PRO 2TB NVMe", category:"stocare", brand:"Samsung",
   image:"https://neocomputer.md/image/cache/data/Componente%20PC/HDD/SSD%20Drives/M.2%20NVMe%20SSD/2.0Tb%20Samsung%20980%20PRO_1-800x800.jpg",
   priceNew:1999, priceOld:2499, discount:20, stock:"În stoc"},
  {id:"d7", name:"AMD Radeon RX 7900 XTX", category:"placi-video", brand:"AMD",
   image:"https://xstore.md/images/product/2024/02/GIGABYTE-Radeon-RX-7900-XTX-GAMING-OC-24G--1-.png",
   priceNew:21499, priceOld:24999, discount:14, stock:"Ultimele 5 bucăți"},
  {id:"d8", name:"Corsair K70 RGB Pro", category:"periferice", brand:"Corsair",
   image:"https://assets.corsair.com/image/upload/c_pad,q_auto,h_1024,w_1024,f_auto/products/Gaming-Keyboards/CH-9109410-NA/Gallery/K70_RGB_PRO_PBT_01.webp",
   priceNew:1499, priceOld:1899, discount:21, stock:"În stoc"},
  {id:"d9", name:"Dell XPS 15 9530", category:"laptopuri", brand:"Dell",
   image:"https://neocomputer.md/image/cache/catalog/category%20image/Dell%20XPS%2015%209530,%20Platinum%20Silver-800x800.jpg",
   priceNew:19999, priceOld:22999, discount:13, stock:"Ultimele 4 bucăți"},
  {id:"d10", name:"Corsair Vengeance DDR5 32GB 6000MHz", category:"stocare", brand:"Corsair",
   image:"https://assets.corsair.com/image/upload/c_pad,q_85,h_1100,w_1100,f_auto/products/Memory/vengeance-rgb-ddr5-blk-config/Gallery/Vengeance-RGB-DDR5-2UP-BLACK_01.webp",
   priceNew:1599, priceOld:1999, discount:20, stock:"În stoc"},
];

let currentDealsFilter = 'toate';

function dealCard(d) {
  return `<div class="deal-card">
    <span class="deal-badge">-${d.discount}% OFF</span>
    <div class="deal-img"><img src="${d.image}" alt="${d.name}" loading="lazy" /></div>
    <div class="deal-info">
      <div class="deal-cat">${d.category.replace('-',' ')}</div>
      <div class="deal-name">${d.name}</div>
      <div class="deal-prices">
        <span class="deal-price-new">${d.priceNew.toLocaleString()} MDL</span>
        <span class="deal-price-old">${d.priceOld.toLocaleString()} MDL</span>
        <span class="deal-save">Economii: ${(d.priceOld-d.priceNew).toLocaleString()} MDL</span>
      </div>
      <div class="deal-stock">${d.stock}</div>
      <button class="btn-primary" style="width:100%;justify-content:center;padding:10px" onclick="addToCart('${d.id}', 1)">Adaugă în Coș</button>
    </div>
  </div>`;
}

function renderDeals() {
  const filtered = currentDealsFilter === 'toate'
    ? dealsData
    : dealsData.filter(d => d.category === currentDealsFilter);
  document.getElementById('deals-grid').innerHTML = filtered.map(dealCard).join('');
}

function filterDeals(cat) {
  currentDealsFilter = cat;
  document.querySelectorAll('.deals-filter-btn').forEach(b => {
    b.classList.toggle('active', b.dataset.filter === cat);
  });
  renderDeals();
}

function startCountdown() {
  const end = new Date();
  end.setHours(23,59,59,0);
  function tick() {
    const now = new Date(), diff = end - now;
    if (diff <= 0) { end.setDate(end.getDate()+1); return; }
    const h = Math.floor(diff/3600000);
    const m = Math.floor((diff%3600000)/60000);
    const s = Math.floor((diff%60000)/1000);
    const pad = n => String(n).padStart(2,'0');
    const hEl = document.getElementById('cd-h');
    const mEl = document.getElementById('cd-m');
    const sEl = document.getElementById('cd-s');
    if(hEl) hEl.textContent = pad(h);
    if(mEl) mEl.textContent = pad(m);
    if(sEl) sEl.textContent = pad(s);
  }
  tick();
  setInterval(tick, 1000);
}

const savedUser = JSON.parse(localStorage.getItem('tc_current_user') || 'null');
if (savedUser) updateNavAuth(savedUser);
renderDeals();
startCountdown();
renderHome();
renderProductFilters();
applyFilters();
renderConfigurator();

let cart = JSON.parse(localStorage.getItem('tc_cart') || '[]');

function saveCart() {
  localStorage.setItem('tc_cart', JSON.stringify(cart));
}

function openCart() {
  document.getElementById('cart-overlay').classList.add('open');
  document.getElementById('cart-panel').classList.add('open');
  renderCart();
}

function closeCart() {
  document.getElementById('cart-overlay').classList.remove('open');
  document.getElementById('cart-panel').classList.remove('open');
}

function addToCart(productId, qty) {
  qty = qty || 1;
  const allProducts = [...products,
    {id:"psu1",name:"Corsair RM850x 850W 80+ Gold",price:1499,image:"https://assets.corsair.com/image/upload/akamai/pdp/rmx2021/images/rm850x_hero.png",brand:"Corsair"},
    {id:"psu2",name:"EVGA SuperNOVA 1000W 80+ Platinum",price:1999,image:"https://www.scan.co.uk/images/products/xlarge/3588591-xl-a.jpg",brand:"EVGA"}
  ];
  const p = allProducts.find(x => x.id === productId);
  if (!p) return;
  const existing = cart.find(i => i.id === productId);
  if (existing) {
    existing.qty += qty;
  } else {
    cart.push({id: p.id, name: p.name, brand: p.brand || '', price: p.price, image: p.image, qty: qty});
  }
  saveCart();
  updateCartBadge();
  showToast('✓ ' + p.name.substring(0, 30) + (p.name.length > 30 ? '...' : '') + ' adăugat în coș');
  renderCart();
}

function removeFromCart(productId) {
  cart = cart.filter(i => i.id !== productId);
  saveCart();
  updateCartBadge();
  renderCart();
}

function updateCartQty(productId, delta) {
  const item = cart.find(i => i.id === productId);
  if (!item) return;
  item.qty = Math.max(1, item.qty + delta);
  saveCart();
  updateCartBadge();
  renderCart();
}

function clearCart() {
  cart = [];
  saveCart();
  updateCartBadge();
  renderCart();
}

function updateCartBadge() {
  const total = cart.reduce((s, i) => s + i.qty, 0);
  const badge = document.getElementById('cart-badge');
  if (badge) {
    badge.textContent = total;
    badge.style.display = total > 0 ? 'flex' : 'none';
  }
}

function cartTotal() {
  return cart.reduce((s, i) => s + i.price * i.qty, 0);
}

function renderCart() {
  const list = document.getElementById('cart-items-list');
  const footer = document.getElementById('cart-footer');
  if (!list) return;
  if (cart.length === 0) {
    list.innerHTML = `<div class="cart-empty">
      <svg viewBox="0 0 24 24" fill="none" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="9" cy="21" r="1"></circle><circle cx="20" cy="21" r="1"></circle><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"></path></svg>
      <p>Coșul tău este gol</p>
    </div>`;
    footer.style.display = 'none';
    return;
  }
  list.innerHTML = cart.map(item => `
    <div class="cart-item">
      <div class="cart-item-img"><img src="${item.image}" alt="${item.name}" /></div>
      <div class="cart-item-info">
        <div class="cart-item-brand">${item.brand}</div>
        <div class="cart-item-name">${item.name}</div>
        <div class="cart-item-bottom">
          <span class="cart-item-price">${(item.price * item.qty).toLocaleString()} MDL</span>
          <div style="display:flex;align-items:center;gap:6px">
            <div class="cart-item-qty">
              <button onclick="updateCartQty('${item.id}', -1)">−</button>
              <span>${item.qty}</span>
              <button onclick="updateCartQty('${item.id}', 1)">+</button>
            </div>
            <button class="cart-item-remove" onclick="removeFromCart('${item.id}')">
              <svg viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6l-1 14H6L5 6"></path><path d="M10 11v6M14 11v6"></path><path d="M9 6V4h6v2"></path></svg>
            </button>
          </div>
        </div>
      </div>
    </div>`).join('');
  const total = cartTotal();
  document.getElementById('cart-subtotal-val').textContent = total.toLocaleString() + ' MDL';
  document.getElementById('cart-total-val').textContent = total.toLocaleString() + ' MDL';
  footer.style.display = 'block';
}

function showToast(msg) {
  const t = document.getElementById('cart-toast');
  t.textContent = msg;
  t.classList.add('show');
  setTimeout(() => t.classList.remove('show'), 2800);
}

function checkout() {
  const total = cartTotal();
  clearCart();
  closeCart();
  showToast('🎉 Comandă plasată! Total: ' + total.toLocaleString() + ' MDL');
}

updateCartBadge();

